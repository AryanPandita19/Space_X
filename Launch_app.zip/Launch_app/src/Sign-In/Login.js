import { Avatar, Button, Grid, Link, Paper, TextField, Typography } from '@mui/material';
import React, { useEffect } from 'react';
import { useState } from 'react';
import './Login.css';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router';
import { toast } from 'react-toastify';
import { signin } from '../Redux/action';
import { AllUsers, LoggedUser, checkCredentials } from '../Redux/reducer';

const Sign = () => {
    const navigate = useNavigate();
    const loggedInUser = useSelector(LoggedUser);
    const CheckCredentials = useSelector(checkCredentials);
    const dispatch = useDispatch();
    const [loginForm, setLoginform] = useState({
        email: "",
        password: "",
    });
    
    const onChangeForm = (label, e) => {
      switch (label) {
        case "email":
          setLoginform({ ...loginForm, email: e.target.value });
          break;
        case "password":
          setLoginform({ ...loginForm, password: e.target.value });
          break;
      }
    };
    useEffect(() => {
      console.log("LggedIn user = ",loggedInUser)
      console.log("checked = ",CheckCredentials)
      if(CheckCredentials){
        toast.success("Sign-in successful");
        navigate("/launch");
      }
      if(CheckCredentials === false){
        toast.error("Invalid Credentials");
      }
    },[loggedInUser,CheckCredentials])

    const login = () => {
      try {
          dispatch(signin(loginForm))
      } catch (error) {
        console.log(error);
        toast.error("Invalid Credentials");
      }
    };
    

    return (
        <Grid>
            <Paper elevation={10} className='sign'>
                <Grid align='center' >
                    <Avatar className='lock'><LockOutlinedIcon/></Avatar>
                    <h2>Sign In</h2>
                </Grid>
                <TextField 
                    className='field' 
                    variant="standard" 
                    label='Email' 
                    placeholder='Email' 
                    type='email'
                    onChange={(e) => {onChangeForm("email", e);}}
                    fullWidth
                    autoComplete="new-email"
                    required/>
                <TextField 
                    className='field' 
                    variant="standard" 
                    label='Password' 
                    placeholder='Password' 
                    type='password'
                    onChange={(e) => {onChangeForm("password", e);}} 
                    fullWidth 
                    autoComplete="new-password"
                    required/>
                <Button type='submit' 
                    color='primary' 
                    variant='contained' 
                    className='enter'
                    onClick={login}
                    fullWidth>
                        Sign In
                </Button>
                <Typography className='link'>
                    Don't have an account? <Link href='/register' >Sign Up</Link>
                </Typography>
            </Paper>
        </Grid>
    );
}

export default Sign;
