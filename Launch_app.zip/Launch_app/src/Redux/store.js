// src/store.js
import {DataReducer } from './reducer';
import { configureStore } from '@reduxjs/toolkit'

export default configureStore({
  reducer: {
    DataState: DataReducer
  },
  middleware: (getDefaultMiddleware) => 
    getDefaultMiddleware({
      serializableCheck: false,
    }),
})
