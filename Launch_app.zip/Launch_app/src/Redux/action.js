// src/actions.js
import { createAction } from '@reduxjs/toolkit'


export const signin = createAction('signin') 
export const signup = createAction('signup')  
export const logout = createAction('logout')  