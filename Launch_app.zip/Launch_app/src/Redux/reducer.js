// src/reducers/index.js
import { createReducer} from '@reduxjs/toolkit';
import { logout, signin, signup } from './action';
const initialState = {
    all_users: [],
    logged_in_user: null,
    checkCredentials: null
  };
  
export const DataReducer = createReducer(initialState, (builder) => {
    builder
      .addCase(signup, (state, action) => {
        return {
          ...state,
          all_users: [...state.all_users, action.payload]
      };  
      })
      .addCase(signin, (state, action) => {
        const userExists = state.all_users.find(user => user.email === action.payload.email && user.password === action.payload.password);

        if (userExists) {
          return {
            ...state,
            logged_in_user: userExists,
            checkCredentials : true
          };
        }
        else{
          return {
            ...state,
            checkCredentials: false
          }
        }
      })
      .addCase(logout, (state, action) => {
          return {
            ...state,
            logged_in_user: null,
            checkCredentials: null
          };
      })
  })
  
  export const AllUsers = (state) => state.DataState.all_users
  export const LoggedUser = (state) => state.DataState.logged_in_user
  export const checkCredentials = (state) => state.DataState.checkCredentials