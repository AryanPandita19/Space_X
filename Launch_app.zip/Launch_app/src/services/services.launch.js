import axios from "axios"

export const GetAllLaunchData = async() => {
    let response = await axios.get(
        "https://api.spacexdata.com/v3/launches"
    )
    return response
}
