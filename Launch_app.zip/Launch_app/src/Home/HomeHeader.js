import React, { useState, useEffect } from 'react'
import Cookies from 'js-cookie'
import LocalLibraryIcon from '@mui/icons-material/LocalLibrary';
import jwt_decode from 'jwt-decode'
import { Button } from "@mui/material";

import './HomeHeader.css'
import { useSelector } from 'react-redux';
import { LoggedUser } from '../Redux/reducer';
const HomeHeader = ({ Logout }) => {
    const [userDetail, setUserDetail] = useState({})
    const LoggedInUser = useSelector(LoggedUser)

    useEffect(() => {
        if(LoggedInUser){
            setUserDetail(LoggedInUser)
        }
    }, [LoggedInUser])

    useEffect(() => {
    },[userDetail])
    return (
        <div className='header'>
            <div className="logo-container">
                <LocalLibraryIcon className="logo" />
            </div>
            <div className="title-container">
                <h3 className="title"> Space X Launches App</h3>
            </div>
            <div className='header-profile'>
                <h4 className="username">{userDetail.name}</h4>
                <Button className="logout-btn" style={{backgroundColor:"whitesmoke",borderRadius:"20px"}} onClick={Logout}>Logout</Button>
            </div>
        </div>
    )
}

export default HomeHeader
