import { useState, useEffect } from "react";
import React from "react";
import { Card, CardContent, CardMedia, Grid, Typography } from '@mui/material';
import "./HomePage.css";
import { GetAllLaunchData } from "../services/services.launch";
import { format } from 'date-fns';
import HomeHeader from "../Home/HomeHeader";
import SearchBar from "../SearchBar";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router";
import { logout } from "../Redux/action";
import { LoggedUser } from "../Redux/reducer";
// Function to format the launch date
const formatDate = (dateString) => {
  const date = new Date(dateString);
  return format(date, 'dd/MM/yyyy');
};

const Home = () => {
  const [launchData, setLaunchData] = useState([]);
  const [showData, setShowData] = useState([]);
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const loggedInUser = useSelector(LoggedUser)
  const handleLogout = () => {
    dispatch(logout())
    navigate("/")
  }

  useEffect(() => {    
    if(!loggedInUser){
      handleLogout()
    }
  },[loggedInUser])

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await GetAllLaunchData();
        if (response && response.status === 200) {
          setLaunchData(response.data);
          setShowData(response.data);
        } else {
          // toast.error("Problem Occurred while fetching book details.Please try after some time.");
        }
      } catch (error) {
        console.error(error);
        // toast.error("Problem Occurred while fetching book details.Please try after some time.");
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
  }, [showData, launchData]);
  return (
    <>
      <HomeHeader Logout={handleLogout}/>
      <SearchBar launchData={launchData} setShowData={setShowData} />
      <div className="book-list" style={{ marginBottom: "20px" }}>
      {showData.map((launch, index) => (
        <Card className="book" sx={{ display: "flex", marginBottom: "10px" }} key={index}>
          <CardMedia
            component="img"
            alt={launch.mission_name}
            image={launch.links.mission_patch}
            sx={{
              width: "50%",
              // objectFit: "cover"
            }}
          />
          <CardContent
            sx={{
              width: "50%",
              overflow: "hidden",
              textOverflow: "ellipsis",
              whiteSpace: "nowrap",
              paddingLeft: "8px",
              textAlign: "center",
            }}
          >
            <Typography variant="h6" component="h6" noWrap>
              {launch.mission_name}
            </Typography>
            <Typography variant="body2" color="textSecondary" component="p" noWrap>
              Launch Date: {formatDate(launch.launch_date_local)}
            </Typography>
            <Typography variant="body2" color="textSecondary" component="p" noWrap>
              Rocket: {launch.rocket.rocket_name}
            </Typography>
            <Typography variant="body2" color="textSecondary" component="p" noWrap>
              Launch Site: {launch.launch_site.site_name}
            </Typography>
          </CardContent>
        </Card>
      ))}
    </div>
    </>
  );
};

export default Home;
