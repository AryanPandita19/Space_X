// import React, { useEffect, useState, useRef } from "react";
// import { Modal, Typography, TextField, Button, InputAdornment } from "@mui/material";
// import SearchIcon from "@mui/icons-material/Search";

// const SearchBar = ({ allBooks, books, setBooks, setAllBooks }) => {
//   const [filter, setFilter] = useState("mission_name");
//   const [query, setQuery] = useState(""); 

//   const handleFilterChange = (e) => {
//     setFilter(e.target.value);
//   };

//   const handleInputChange = (e) => {
//     setQuery(e.target.value);
//   };
//   useEffect(() => {
//     if(filter === 'mission_name'){
//       const filtered = allBooks.filter((book) =>
//       // console.log(book[filter]),
//         book[filter].toLowerCase().includes(query.toLowerCase())
//       );
//       setBooks(filtered);
//     }
//     else{
       
//     }
//   },[filter,query])
//   return (
//     <div
//       style={{
//         display: "flex",
//         justifyContent: "space-between",
//         alignItems: "center",
//         height: "30px",
//         padding: "8px 4px",
//         marginBottom: "10px",
//         marginTop: "10px",
//       }}
//     >
//       <div style={{ display: "flex", height: "100%" }}>
//       <select
//           value={filter}
//           onChange={handleFilterChange}
//           style={{ height: "100%", marginRight: "5px", width: "100px" }}
//         >
//           <option value="mission_name">Title</option>
//           <option value="launch_year">launch year</option>
//           <option value="status">status</option>
//         </select>
//         <TextField
//           type="text"
//           value={query}
//           onChange={handleInputChange}
//           placeholder="Search for books..."
//           InputProps={{
//             style: {
//               height: "30px",
//             },
//             startAdornment: (
//               <InputAdornment position="start">
//                 <SearchIcon />
//               </InputAdornment>
//             ),
//           }}
//         />
//       </div>
//     </div>
//   );
// };

// export default SearchBar;
import React, { useEffect, useState } from "react";
import { TextField, InputAdornment, MenuItem, Select, FormControl, InputLabel, Checkbox, FormControlLabel } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";

const SearchBar = ({ launchData, setShowData }) => {
  const [filter, setFilter] = useState("mission_name");
  const [query, setQuery] = useState("");
  const [selectedYear, setSelectedYear] = useState("");
  const [launchSuccess, setLaunchSuccess] = useState(false);

  const handleFilterChange = (e) => {
    setFilter(e.target.value);
    setQuery(""); // Reset the query when the filter changes
    setSelectedYear("");
    setLaunchSuccess(false);
  };

  const handleInputChange = (e) => {
    setQuery(e.target.value);
  };

  const handleYearChange = (e) => {
    setSelectedYear(e.target.value);
  };

  const handleLaunchSuccessChange = (e) => {
    setLaunchSuccess(e.target.checked);
  };

  useEffect(() => {
    let filtered = launchData;
    if (filter === 'mission_name') {
      filtered = launchData.filter((book) =>
        book[filter].toLowerCase().includes(query.toLowerCase())
      );
    } else if (filter === 'launch_year') {
      if(selectedYear){
      filtered = launchData.filter((book) =>
        book[filter] === selectedYear
      );
    }
    } else if (filter === 'launch_success') {
      filtered = launchData.filter((book) =>
        book[filter] === launchSuccess
      );
    }
    setShowData(filtered);
  }, [filter, query, selectedYear, launchSuccess, launchData, setShowData]);

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        height: "30px",
        padding: "8px 4px",
        marginBottom: "10px",
        marginTop: "10px",
      }}
    >
      <div style={{ display: "flex", height: "100%" }}>
        <FormControl variant="outlined" style={{ marginRight: "10px", width: "150px" }}>
          <InputLabel>Filter By</InputLabel>
          <Select value={filter} onChange={handleFilterChange} label="Filter By">
            <MenuItem value="mission_name">Title</MenuItem>
            <MenuItem value="launch_year">Launch Year</MenuItem>
            <MenuItem value="launch_success">Launch Success</MenuItem>
          </Select>
        </FormControl>
        {filter === 'mission_name' && (
          <TextField
            type="text"
            value={query}
            onChange={handleInputChange}
            placeholder="Search for books..."
            InputProps={{
              style: {
                height: "30px",
              },
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
          />
        )}
        {filter === 'launch_year' && (
          <TextField
            type="number"
            value={selectedYear}
            onChange={handleYearChange}
            placeholder="Enter launch year..."
            InputProps={{
              style: {
                height: "30px",
              },
            }}
          />
        )}
        {filter === 'launch_success' && (
          <FormControlLabel
            control={
              <Checkbox
                checked={launchSuccess}
                onChange={handleLaunchSuccessChange}
                color="primary"
              />
            }
            label="Launch Success"
          />
        )}
      </div>
    </div>
  );
};

export default SearchBar;
